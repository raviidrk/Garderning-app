
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: false,
  baseHref: "/",
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "preload": [
      "chunk-D2NZJHLK.js",
      "chunk-2K4HK3V7.js"
    ],
    "route": "/"
  },
  {
    "renderMode": 2,
    "preload": [
      "chunk-Z5ODMEWX.js",
      "chunk-2K4HK3V7.js"
    ],
    "route": "/shop"
  },
  {
    "renderMode": 2,
    "preload": [
      "chunk-TEXUTYP5.js"
    ],
    "route": "/orders"
  },
  {
    "renderMode": 2,
    "preload": [
      "chunk-2DF2X4YK.js"
    ],
    "route": "/about"
  },
  {
    "renderMode": 2,
    "preload": [
      "chunk-IRYX2PI6.js"
    ],
    "route": "/contact"
  },
  {
    "renderMode": 2,
    "redirectTo": "/",
    "route": "/**"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    "index.csr.html": {size: 1695, hash: "702c2bf3fcef5215d0346ec3e6150d026249fa3c3c5cd9caa8f300aac3ffe7ed", text: () => import("./assets-chunks/index_csr_html.mjs").then(m => m.default)},
    "index.server.html": {size: 2235, hash: "15dedd00d238f433647cc0c0d601870a2763c60465fac965f279bfa9557a06c4", text: () => import("./assets-chunks/index_server_html.mjs").then(m => m.default)},
    "about/index.html": {size: 25491, hash: "0aac55baaa7d14d3ac326481070664f3fd03f66a28b47aa315d61cdddb48ddb7", text: () => import("./assets-chunks/about_index_html.mjs").then(m => m.default)},
    "index.html": {size: 114806, hash: "94b0df98e24fa8043fcacd49b06d5507b88547490adb7152b8de2e052a7db6a3", text: () => import("./assets-chunks/index_html.mjs").then(m => m.default)},
    "orders/index.html": {size: 36598, hash: "2f8e07c6a200718e92e9bfe3187a5673649ea36f7323f27598670ffafde1ea61", text: () => import("./assets-chunks/orders_index_html.mjs").then(m => m.default)},
    "shop/index.html": {size: 117465, hash: "6e696ec6fc3bca8e7ffb9dd2d95aab4ae9e14528f03cd4c6a3d869dcd4544e5b", text: () => import("./assets-chunks/shop_index_html.mjs").then(m => m.default)},
    "contact/index.html": {size: 32188, hash: "7050ee9744d2612722c22322a736ed4145baa92a50b11fc7299f082d928bda4a", text: () => import("./assets-chunks/contact_index_html.mjs").then(m => m.default)}
  },
};

export default `<!doctype html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="utf-8">
  <title>Babu Organic Garden | A Farm Sustainability - Organic Plants, Seeds & Gardening</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Babu Organic Garden - A Farm Sustainability. Premium indoor &amp; outdoor plants, native organic seeds, natural vermicompost, UV grow bags, live plant delivery &amp; garden solutions.">
  <meta name="theme-color" content="#1b4332">
  <link rel="icon" type="image/jpeg" href="/images/logo.jpg">
  
  <!-- Preconnect to Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&amp;family=Noto+Sans+Tamil:wght@400;500;600;700&amp;family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">
  
  <!-- Manifest for PWA -->
  <link rel="manifest" href="/manifest.webmanifest">
<link rel="stylesheet" href="styles-CZY6WM7S.css"></head>
<body class="bg-[#fbf9f4] text-zinc-800 antialiased selection:bg-emerald-700 selection:text-white dark:bg-[#0c1812] dark:text-zinc-100 min-h-screen flex flex-col font-sans transition-colors duration-200"><script type="text/javascript" id="ng-event-dispatch-contract">(()=>{function p(t,n,r,o,e,i,f,m){return{eventType:t,event:n,targetElement:r,eic:o,timeStamp:e,eia:i,eirp:f,eiack:m}}function u(t){let n=[],r=e=>{n.push(e)};return{c:t,q:n,et:[],etc:[],d:r,h:e=>{r(p(e.type,e,e.target,t,Date.now()))}}}function s(t,n,r){for(let o=0;o<n.length;o++){let e=n[o];(r?t.etc:t.et).push(e),t.c.addEventListener(e,t.h,r)}}function c(t,n,r,o,e=window){let i=u(t);e._ejsas||(e._ejsas={}),e._ejsas[n]=i,s(i,r),s(i,o,!0)}window.__jsaction_bootstrap=c;})();
</script>
  <app-root></app-root>
<link rel="modulepreload" href="chunk-65EGSR25.js"><link rel="modulepreload" href="chunk-CD466MRK.js"><link rel="modulepreload" href="chunk-C5CSKL24.js"><link rel="modulepreload" href="chunk-N2YAB4P2.js"><script src="main-Y6IRXYEN.js" type="module"></script></body>
</html>
`;